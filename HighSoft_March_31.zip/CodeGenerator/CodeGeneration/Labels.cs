using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Collections;
using System;
using System.Collections.Specialized;
using System.Web;
using System.IO;

namespace Highsoft.Web.Mvc
{
	public partial class Labels
	{
		public Labels()
		{
			Items = Items_DefaultValue = new LabelsItems();
			Style = Style_DefaultValue = null;
			
		}	
		

		/// <summary>
		/// A HTML label that can be positioned anywhere in the chart area.
		/// </summary>
		public LabelsItems Items { get; set; }
		private LabelsItems Items_DefaultValue { get; set; }
		 

		/// <summary>
		/// Shared CSS styles for all labels. Defaults to:<pre>style: {color: '#3E576F'}</pre>
		/// </summary>
		public NameValueCollection Style { get; set; }
		private NameValueCollection Style_DefaultValue { get; set; }
		  

		internal Hashtable ToHashtable()
		{
			Hashtable h = new Hashtable();

			if (Items.IsDirty()) h.Add("items",Items.ToHashtable());
			if (Style != Style_DefaultValue) h.Add("style",Style);
			

			return h;
		}

		internal string ToJSON()
		{            
			Hashtable h = ToHashtable();
			if (h.Count > 0)
				return new JavaScriptSerializer().Serialize(ToHashtable());
			else 
				return "";
		}       

		// checks if the state of the object is different from the default
		// and therefore needs to be serialized
		internal bool IsDirty()
		{
			return ToHashtable().Count > 0;
		}
	}
}