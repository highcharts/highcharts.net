﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_Demo.Models
{
    public class FlagData
    {
        public double? Date { get; set; }
        public double? Value { get; set; }
    }
}