using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Highsoft.Web.Mvc.Highcharts
{
    public enum YAxisMinorTickPosition
    {
        Inside, 
		Outside
    }
}
