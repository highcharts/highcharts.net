﻿using Highsoft.Web.Mvc.Stocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Demo.Areas.Highstock.Controllers.Shared
{
    public partial class SharedController : Controller
    {
        public ActionResult DynamicUpdate()
        {
            return View();
        }

    }
}
