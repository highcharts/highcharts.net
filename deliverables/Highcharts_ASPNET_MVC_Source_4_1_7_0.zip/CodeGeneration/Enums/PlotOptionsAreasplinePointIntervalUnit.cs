using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Highsoft.Web.Mvc
{
    public enum PlotOptionsAreasplinePointIntervalUnit
    {
        Null, 
		Month, 
		Year
    }
}
