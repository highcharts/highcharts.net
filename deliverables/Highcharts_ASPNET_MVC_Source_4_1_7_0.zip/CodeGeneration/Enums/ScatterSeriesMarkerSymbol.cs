using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Highsoft.Web.Mvc
{
    public enum ScatterSeriesMarkerSymbol
    {
        Null, 
		Circle, 
		Square, 
		Diamond, 
		Triangle, 
		Triangledown
    }
}
