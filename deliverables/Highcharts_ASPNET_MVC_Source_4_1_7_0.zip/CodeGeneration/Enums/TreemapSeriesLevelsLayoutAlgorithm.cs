using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Highsoft.Web.Mvc
{
    public enum TreemapSeriesLevelsLayoutAlgorithm
    {
        Null, 
		SliceAndDice, 
		Stripes, 
		Squarified, 
		Strip
    }
}
