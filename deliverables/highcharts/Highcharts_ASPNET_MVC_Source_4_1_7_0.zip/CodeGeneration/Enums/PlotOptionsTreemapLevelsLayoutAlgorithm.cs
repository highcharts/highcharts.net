using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Highsoft.Web.Mvc.Charts
{
    public enum PlotOptionsTreemapLevelsLayoutAlgorithm
    {
        Null, 
		SliceAndDice, 
		Stripes, 
		Squarified, 
		Strip
    }
}
