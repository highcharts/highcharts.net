using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using sample_project.Models;
using Trirand.Web.Mvc;

namespace sample_project.Controllers
{
    public class TreeViewController : Controller
    {
        public ActionResult TreeViewDemo()
        {
            return View();
        }

        public JsonResult TreeView_TextAndImages_DataRequested()
        {
            var tree = new JQTreeView();

            List<JQTreeNode> nodes = new List<JQTreeNode>();

            nodes.Add(new LeafNode { Text = "One" });
            nodes.Add(new FolderNode { Text = "Two", Expanded = true });
            nodes.Add(new LeafNode { Text = "Three" });

            var secondNode = nodes.Find(n => n.Text == "Two");

            secondNode.Nodes.Add(new LeafNode { Text = "2.1" });
            secondNode.Nodes.Add(new FolderNode { Text = "2.2", Expanded = true });
            secondNode.Nodes.Add(new LeafNode { Text = "2.3" });

            secondNode.Nodes.Find(n => n.Text == "2.2").Nodes.Add(new LeafNode { Text = "2.2.1" });
            secondNode.Nodes.Find(n => n.Text == "2.2").Nodes.Add(new LeafNode { Text = "2.2.2" });
            secondNode.Nodes.Find(n => n.Text == "2.2").Nodes.Add(new LeafNode { Text = "2.2.4" });
            secondNode.Nodes.Find(n => n.Text == "2.2").Nodes.Add(new LeafNode { Text = "2.2.3" });

            return tree.DataBind(nodes);
        }

        public class FolderNode : JQTreeNode
        {
            public FolderNode()
            {
                ImageUrl = "/content/images/folder.png";
                ExpandedImageUrl = "/content/images/folder-open.png";
            }
        }

        public class LeafNode : JQTreeNode
        {
            public LeafNode()
            {
                ImageUrl = "/content/images/document.png";
            }
        }
    }
}
