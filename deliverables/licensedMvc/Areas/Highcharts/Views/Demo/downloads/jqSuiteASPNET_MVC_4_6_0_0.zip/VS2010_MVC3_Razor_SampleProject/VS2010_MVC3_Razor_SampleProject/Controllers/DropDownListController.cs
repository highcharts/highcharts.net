﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace VS2010_MVC3_Razor_SampleProject.Controllers
{
    public class DropDownListController : Controller
    {
        //
        // GET: /DropDownList/

        public ActionResult DropDownListDemo()
        {
            return View();
        }

    }
}
